'''
to implement the needed library
The command line parameters are obtained using the sys library.
heapq: The priority queue is implemented using the heapq library.
time: The time library is used to compute the time required to solve the puzzle copy: The copy library is used to duplicate the puzzle's state.
os: The os library is used to determine the current working directory.
The command line parameters are parsed using the argparse library.
collections: The queue is implemented using the collections library.
The pprint library is used to print the problem in a more readable style.
'''

import sys
import heapq
import time
import copy
import os
import argparse
import collections

# deque is used to implement the queue
from collections import deque

'''
This is a Python class definition for a node in a puzzle-solving algorithm. Specifically, this node class is used to store the state of the puzzle, the parent node, the action taken to reach the current state, and the cost of the current state.
The __init__ method initializes the node with the given state, parent, action, and cost. The state parameter is used to store the current state of the puzzle, parent is used to store a reference to the parent node, action is used to store the action taken to reach the current state, and cost is used to store the cost of the current state.
The __lt__ method is used to compare two nodes based on their cost. This is used in the priority queue to determine which node to explore next.
The __eq__ method is used to compare two nodes based on their state. This is used to check whether a node is already in the explored set.
The __hash__ method is used to hash the state of the node. This is used to store the node in a hash set, which is used to check whether a node is already in the explored set.
The __str__ method is used to print the state of the node. This is mainly for debugging purposes. It returns a string representation of the node's state.
'''

class Node:
    def __init__(self, state, parent=None, action=None, cost=0):
        self.state = state
        self.parent = parent
        self.action = action
        self.cost = cost
        
    def __lt__(self, other):
        return self.cost < other.cost
    
    def __eq__(self, other):
        return self.state == other.state
    
    def __hash__(self):
        return hash(self.state)
    
    def __str__(self):
        temp = ''
        for item in self.state:
            for i in item:
                temp += str(i) + ' '
        return temp
     
    
'''
This is a Python function definition for parsing an input file that contains the initial state of the puzzle. The function takes the name of the input file as input and returns the state of the puzzle as a 3x3 matrix.
The with open() statement is used to open the input file in read mode. The readlines() method is used to read all the lines in the input file as a list of strings. The strip() method is used to remove any whitespace characters from the beginning and end of each line. The last line of the input file is then removed because it is not part of the puzzle state.
The for loop is used to iterate over each line in the list of lines. Each line is split into a list of strings using the split() method, and the resulting list of strings is converted to a list of integers using the int() function. This creates a 3x3 matrix of integers that represents the state of the puzzle.
'''

def file_to_matrix(file_name): # This function is used to parse the input file and return the state of the puzzle
    with open(file_name, 'r') as f:
        lines = f.readlines()
        lines = [line.strip() for line in lines]
        lines = lines[:-1] # The last line is not required
        for i in range(len(lines)): # The state of the puzzle is stored in a 3x3 matrix
            lines[i] = lines[i].split()
            for j in range(len(lines[i])):
                lines[i][j] = int(lines[i][j])
        return lines # The state of the puzzle is returned

'''
Blanks are represented by 0 in the state of the puzzle. This function is used to find the position of the blank tile in the state of the puzzle. The function takes the state of the puzzle as input and returns the position of the blank tile as a tuple of integers.
The for loop is used to iterate over each row in the state of the puzzle. The for loop is nested inside the for loop, and is used to iterate over each column in the state of the puzzle. If the current element is equal to 0, then the position of the blank tile is returned as a tuple of integers.
'''
 
def blank_tile(state): # helper function to get the blank tile
    for i in range(3):
        for j in range(3):
            if state[i][j] == 0:
                return (i, j)
    return None

'''
This is a Python function definition for generating the child nodes of a given node. The function takes the node as input and returns a list of child nodes.
The blank_tile() function is used to get the position of the blank tile in the state of the puzzle. The get_actions() function is used to get the list of actions that can be taken from the current state of the puzzle. The for loop is used to iterate over each action in the list of actions. The copy.deepcopy() function is used to create a deep copy of the state of the puzzle. The blank_tile() function is used to get the position of the blank tile in the state of the puzzle. The for loop is used to iterate over each row in the state of the puzzle. The for loop is nested inside the for loop, and is used to iterate over each column in the state of the puzzle. If the current element is equal to 0, then the position of the blank tile is stored in the variables i and j.
The if statement is used to check whether the action is to move the tile above the blank tile up. If the action is to move the tile above the blank tile up, then the element above the blank tile is swapped with the blank tile. The new state is then appended to the list of child nodes.
The elif statement is used to check whether the action is to move the tile below the blank tile down. If the action is to move the tile below the blank tile down, then the element below the blank tile is swapped with the blank tile. The new state is then appended to the list of child nodes.
The elif statement is used to check whether the action is to move the tile to the left of the blank tile left. If the action is to move the tile to the left of the blank tile left, then the element to the left of the blank tile is swapped with the blank tile. The new state is then appended to the list of child nodes.
The elif statement is used to check whether the action is to move the tile to the right of the blank tile right. If the action is to move the tile to the right of the blank tile right, then the element to the right of the blank tile is swapped with the blank tile. The new state is then appended to the list of child nodes.
'''

def get_actions(state): 
    actions = []
    blank = blank_tile(state)
    if blank is None:
        return actions
    
    i, j = blank
    if i > 0:
        actions.append(f'Move {state[i-1][j]} Up')
    if i < 2:
        actions.append(f'Move {state[i+1][j]} Down')
    if j > 0:
        actions.append(f'Move {state[i][j-1]} Left')
    if j < 2:
        actions.append(f'Move {state[i][j+1]} Right')
    return actions

'''
Get successor state of the current state. The function takes the state of the puzzle and the action to be taken as input and returns the successor state of the current state.
The copy.deepcopy() function is used to create a deep copy of the state of the puzzle. The blank_tile() function is used to get the position of the blank tile in the state of the puzzle. The for loop is used to iterate over each row in the state of the puzzle. The for loop is nested inside the for loop, and is used to iterate over each column in the state of the puzzle. If the current element is equal to 0, then the position of the blank tile is stored in the variables i and j.
The if statement is used to check whether the action is to move the tile above the blank tile up. If the action is to move the tile above the blank tile up, then the element above the blank tile is swapped with the blank tile. The new state is then returned.
The elif statement is used to check whether the action is to move the tile below the blank tile down. If the action is to move the tile below the blank tile down, then the element below the blank tile is swapped with the blank tile. The new state is then returned.
The elif statement is used to check whether the action is to move the tile to the left of the blank tile left. If the action is to move the tile to the left of the blank tile left, then the element to the left of the blank tile is swapped with the blank tile. The new state is then returned.
The elif statement is used to check whether the action is to move the tile to the right of the blank tile right. If the action is to move the tile to the right of the blank tile right, then the element to the right of the blank tile is swapped with the blank tile. The new state is then returned.
'''

def get_successor(state, action): 
    suc = copy.deepcopy(state)
    blank = blank_tile(suc)
    i, j = blank
    if 'Up' in action:
        suc[i][j] = suc[i-1][j]
        suc[i-1][j] = 0
    elif 'Down' in action:
        suc[i][j] = suc[i+1][j]
        suc[i+1][j] = 0
    elif 'Left' in action:
        suc[i][j] = suc[i][j-1]
        suc[i][j-1] = 0
    elif 'Right' in action:
        suc[i][j] = suc[i][j+1]
        suc[i][j+1] = 0
    return suc


'''   
get cost of the action taken to reach the current state. The function takes the action as input and returns the cost of the action. The cost of the action is the number in the action.
'''

def get_cost(action_of_node): 
    return int(action_of_node.split()[1])

'''
get path from the start state to the goal state. The function takes the node as input and returns the path from the start state to the goal state. The path is stored in a list. The path is traversed from the goal state to the start state. The action taken to reach the current state is appended to the path. The parent node is set as the current node. The path is reversed to get the path from the start state to the goal state. The path is returned.
'''

def get_path(node_of_node):
    path = []
    while node_of_node.parent is not None:
        path.append(node_of_node.action)
        node_of_node = node_of_node.parent
    path.reverse()
    return path

'''
get cost of the path from the start state to the goal state. The function takes the node as input and returns the cost of the path from the start state to the goal state. The cost of the path is the sum of the costs of the actions taken to reach the goal state from the start state. The cost of the action is the number in the action. The cost of the path is the sum of the costs of the actions taken to reach the goal state from the start state. The parent node is set as the current node. The cost of the path is returned.
'''

def get_path_cost(node_of_node):
    cost = 0
    while node_of_node.parent is not None:
        cost += node_of_node.cost
        node_of_node = node_of_node.parent
    return cost

'''
get depth of the path from the start state to the goal state. The function takes the node as input and returns the depth of the path from the start state to the goal state. The depth of the path is the number of actions taken to reach the goal state from the start state. The parent node is set as the current node. The depth of the path is returned.
'''

def get_path_depth(node_of_node):
    depth = 0
    while node_of_node.parent is not None:
        depth += 1
        node_of_node = node_of_node.parent
    return depth

'''
This is a Python function definition for generating the child nodes of a given node. The function takes the node as input and returns a list of child nodes.
The get_actions() function is used to get the list of actions that can be taken from the current state of the puzzle. The for loop is used to iterate over each action in the list of actions. The copy.deepcopy() function is used to create a deep copy of the state of the puzzle. The get_successor() function is used to get the successor state of the current state. The Node() function is used to create a new node with the successor state as the state of the puzzle. The new node is then appended to the list of child nodes.
'''

def get_child_nodes(node_of_node):
    child_nodes = []
    actions = get_actions(node_of_node.state)
    while actions:
        action = actions.pop()
        successor = get_successor(node_of_node.state, action)
        child_nodes.append(Node(successor, node_of_node, action))
    return child_nodes


class Algorithms:
    def __init__(self, start_state, goal_state,algorithm,dump_flag):
        self.start_state = start_state
        self.goal_state = goal_state
        self.start_node = Node(start_state, None, None)
        self.goal_node = Node(goal_state, None, None)
        self.frontier = []
        self.explored = []
        self.path = []
        self.path_cost = 0
        self.path_depth = 0
        self.nodes_popped = 0
        self.nodes_expanded = 0
        self.max_frontier_size = 0
        self.depth = 4 # let take depth as 4 for now
        self.dump_flag = dump_flag
        self.algorithm = algorithm
        self.node_generated = 0


    def bfs(self):
        """Performs a breadth-first search to find a path from start to goal state"""
        frontier = deque([self.start_node])  # initialize the frontier with the start node
        explored = set()  # initialize the explored set to be empty

        while frontier:  # loop while there are nodes in the frontier
            node = frontier.popleft()  # choose the shallowest node in the frontier

            if node.state == self.goal_state:  # if the goal state is reached, construct the path and return it
                path = []
                path_cost = 0
                path_depth = 0
                while node.parent is not None:
                    # path.append(node)
                    # path.append(get_actions(node.state))
                    actions = get_actions(node.state)
                    for action in actions:
                        successor = get_successor(node.state, action)
                        if successor == node.parent.state:
                            # moves.append(action)
                            path_cost+=int(action.split()[1])
                            path.append(action)
                    path_cost += node.cost 
                    path_depth += 1
                    node = node.parent
                self.path = list(reversed(path))
                self.path_cost = path_cost
                self.path_depth = path_depth
                self.nodes_popped = len(explored)
                self.nodes_expanded = self.nodes_popped + len(frontier)
                self.max_frontier_size = self.nodes_expanded
                return self.path

            # explored.add(node.state)  # add the node's state to the explored set uhashable type: 'list'
            # hash the node's state to make it hashable
            explored.add(hash(str(node.state)))

            # generate the node's successors and add them to the frontier if they have not been explored
            actions = get_actions(node.state)
            for action in actions:
                successor = get_successor(node.state, action)
                # if successor not in explored:  # uhashable type: 'list'
                # hash the successor to make it hashable
                if hash(str(successor)) not in explored:
                    self.node_generated += 1
                    frontier.append(Node(successor, node, action))

        return None  # if the goal state is not found, return None
    
    def dfs(self):
        """Performs a depth-first search to find a path from start to goal state"""
        frontier = [self.start_node]  # initialize the frontier with the start node
        explored = set()  # initialize the explored set to be empty

        while frontier:  # loop while there are nodes in the frontier
            node = frontier.pop()  # choose the deepest node in the frontier

            if node.state == self.goal_state:  # if the goal state is reached, construct the path and return it
                path = []
                path_cost = 0
                path_depth = 0
                while node.parent is not None:
                    # path.append(node) use get actions and get successor to get the path
                    # path.append(get_actions(node.state))
                    actions = get_actions(node.state)
                    for action in actions:
                        successor = get_successor(node.state, action)
                        if successor == node.parent.state:
                            # moves.append(action)
                            path_cost+=int(action.split()[1])
                            path.append(action)
                    path_cost += node.cost
                    path_depth += 1
                    node = node.parent
                # path.append(get_actions(self.start_node.state))
                self.path = list(reversed(path))
                self.path_cost = path_cost
                self.path_depth = path_depth
                self.nodes_popped = len(explored)
                self.nodes_expanded = self.nodes_popped + len(frontier)
                self.max_frontier_size = self.nodes_expanded
                return self.path

            # explored.add(node.state)  # add the node's state to the explored set uhashable type: 'list'
            # hash the node's state to make it hashable
            explored.add(hash(str(node.state)))
             
            
            # generate the node's successors and add them to the frontier if they have not been explored
            actions = get_actions(node.state)
            for action in actions:
                successor = get_successor(node.state, action)
                # if successor not in explored:  # uhashable type: 'list'
                # hash the successor to make it hashable
                if hash(str(successor)) not in explored:
                    # cost  can be added here
                    self.node_generated += 1
                    frontier.append(Node(successor, node, action))

        return None  # if the goal state is not found, return None

    def ids(self):
        """Performs Iterative Deepening Search to find a path from start to goal state"""
        depth = 0
        while True:
            result = self.depth_limited_search(depth)
            if result is not None:
                return result
            depth += 1
    
    def depth_limited_search(self, limit):
        """Performs depth-limited search to find a path from start to goal state"""
        frontier = [(self.start_node, 0)]  # initialize the frontier with the start node and its depth
        explored = set()  # initialize the explored set to be empty
        c=0
        while frontier:  # loop while there are nodes in the frontier
            node, depth = frontier.pop()  # choose the deepest node in the frontier
            
            if node.state == self.goal_state:  # if the goal state is reached, construct the path and return it
                path = []
                path_cost = 0
                path_depth = 0
                while node.parent is not None:
                    path.append(node.action)
                    cost = action.split()[1]
                    path_cost += node.cost+int(cost)
                    path_depth += 1
                    node = node.parent
                self.path = list(reversed(path))
                self.path_cost = path_cost
                self.path_depth = path_depth
                self.nodes_popped = len(explored)
                self.nodes_expanded = self.nodes_popped + len(frontier)
                self.max_frontier_size = self.nodes_expanded
                return self.path

            if depth < limit:  # if depth limit has not been reached yet
                explored.add(hash(str(node.state)))  # add the node's state to the explored set

                # generate the node's successors and add them to the frontier if they have not been explored
                actions = get_actions(node.state)
                for action in actions:
                    successor = get_successor(node.state, action)
                    if hash(str(successor)) not in explored:
                        self.node_generated += 1
                        frontier.append((Node(successor, node, action), depth + 1))

        return None  # if the goal state is not found, return None
         
    def dls(self):
        # ask for depth limit and then call depth limited search
        self.depth = int(input("Enter depth limit: "))
        self.depth_limited_search(self.depth)
        
    def heuristic(self, node):
        """Returns the Manhattan distance between a node and the goal node"""
        distance = 0
        for i in range(3):
            for j in range(3):
                if node.state[i][j] != 0:
                    goal_row = (node.state[i][j] - 1) // 3
                    goal_col = (node.state[i][j] - 1) % 3
                    distance += abs(i - goal_row) + abs(j - goal_col)
        return distance

    def a_star(self):
        """Performs A* search to find a path from start to goal state"""
        heapq.heappush(self.frontier, self.start_node)  # initialize the frontier with the start node

        while self.frontier:  # loop while there are nodes in the frontier
            node = heapq.heappop(self.frontier)  # choose the node with the lowest f(n)

            if node.state == self.goal_state:  # if the goal state is reached, construct the path and return it
                path = []
                moves = []
                path_cost = 0
                path_depth = 0
                while node.parent is not None:
                    # what we have changed
                    # path.append(node.state)
                    actions = get_actions(node.state)
                    for action in actions:
                        successor = get_successor(node.state, action)
                        if successor == node.parent.state:
                            # moves.append(action)
                            path.append(action)
                    path_cost += node.cost
                    path_depth += 1
                    node = node.parent
                
                self.path = list(reversed(path))
                self.path_cost = path_cost
                self.path_depth = path_depth
                self.nodes_popped = len(self.explored)
                self.nodes_expanded = self.nodes_popped + len(self.frontier)
                self.max_frontier_size = self.nodes_expanded
                return self.path

            self.explored.append(node.state)  # add the node's state to the explored set

            # generate the node's successors and add them to the frontier if they have not been explored
            actions = get_actions(node.state)
            for action in actions:
                successor_state = get_successor(node.state, action)
                successor = Node(successor_state, node, node.cost + 1, action)
                if successor.state not in self.explored and successor not in self.frontier:
                    # successor.cost = node.cost + successor.cost + self.heuristic(successor)
                    cost = successor.cost.split(' ')
                    successor.cost = node.cost + int(cost[1]) + self.heuristic(successor)
                    self.node_generated += 1
                    heapq.heappush(self.frontier, successor)
                    self.max_frontier_size = max(self.max_frontier_size, len(self.frontier))

        return None  # if the goal state is not found, return None
    
    #greedy search algorithm
    def greedy_search(self):
        """Performs greedy search to find a path from start to goal state"""
        heapq.heappush(self.frontier, self.start_node)  # initialize the frontier with the start node

        while self.frontier:  # loop while there are nodes in the frontier
            node = heapq.heappop(self.frontier)  # choose the node with the lowest h(n)

            if node.state == self.goal_state:  # if the goal state is reached, construct the path and return it
                path = []
                path_cost = 0
                path_depth = 0
                while node.parent is not None:
                    # path.append(get_actions(node.state))
                    actions = get_actions(node.state)
                    for action in actions:
                        successor = get_successor(node.state, action)
                        if successor == node.parent.state:
                            # moves.append(action)
                            path.append(action)
                    path_cost += node.cost
                    path_depth += 1
                    node = node.parent
                # path.append(get_actions(self.start_node.state))
                self.path = list(reversed(path))
                self.path_cost = path_cost
                self.path_depth = path_depth
                self.nodes_popped = len(self.explored)
                self.nodes_expanded = self.nodes_popped + len(self.frontier)
                self.max_frontier_size = self.nodes_expanded
                return self.path

            self.explored.append(node.state)  # add the node's state to the explored set

            # generate the node's successors and add them to the frontier if they have not been explored
            actions = get_actions(node.state)
            for action in actions:
                successor_state = get_successor(node.state, action)
                successor = Node(successor_state, node, node.cost + 1, action)
                if successor.state not in self.explored and successor not in self.frontier:
                    successor.cost = self.heuristic(successor) # set the cost to be the heuristic value only
                    self.node_generated += 1
                    heapq.heappush(self.frontier, successor)
                    self.max_frontier_size = max(self.max_frontier_size, len(self.frontier))

        return None  # if the goal state is not found, return None

    def uniform_cost(self): 
        heapq.heappush(self.frontier, self.start_node)  # initialize the frontier with the start node

        while self.frontier:  # loop while there are nodes in the frontier
            node = heapq.heappop(self.frontier)  # choose the node with the lowest f(n)

            if node.state == self.goal_state:  # if the goal state is reached, construct the path and return it
                path = []
                path_cost = 0
                path_depth = 0
                while node.parent is not None:
                    # path.append(get_actions(node.state))
                    actions = get_actions(node.state)
                    for action in actions:
                        successor = get_successor(node.state, action)
                        if successor == node.parent.state:
                            # moves.append(action)
                            path.append(action)
                    path_cost += node.cost
                    path_depth += 1
                    node = node.parent
                # path.append(get_actions(self.start_node.state))
                self.path = list(reversed(path))
                self.path_cost = path_cost
                self.path_depth = path_depth
                self.nodes_popped = len(self.explored)
                self.nodes_expanded = self.nodes_popped + len(self.frontier)
                self.max_frontier_size = self.nodes_expanded
                return self.path

            self.explored.append(node.state)  # add the node's state to the explored set

            # generate the node's successors and add them to the frontier if they have not been explored
            actions = get_actions(node.state)
            for action in actions:
                successor_state = get_successor(node.state, action)
                successor = Node(successor_state, node, node.cost + 1, action)
                if successor.state not in self.explored and successor not in self.frontier:
                    cost = successor.cost.split(' ')
                    successor.cost = node.cost + int(cost[1])
                    self.node_generated += 1
                    heapq.heappush(self.frontier, successor)
                    self.max_frontier_size = max(self.max_frontier_size, len(self.frontier))

        return None  # if the goal state is not found, return None

    #print the result
    def print_result(self):
        print('Nodes Popped: {} \nNodes Expanded: {} \nNodes Generated: {} \nMax Fringe Size: {}'.format(self.nodes_popped, self.nodes_expanded, self.node_generated, self.max_frontier_size))
        if self.path is not None:
            print('\tPath Cost: {}'.format(self.path_cost))
            print('\tPath Depth: {}'.format(self.path_depth))
            for action in self.path:
                print("\t{}".format(action))
        else:
            print('No Solution')
    # dump file write
    def dump_file(self):
        trace_file = 'trace-{}.txt'.format(time.strftime("%Y%m%d-%H%M%S"))
        if self.dump_flag:
            with open(trace_file, 'a') as f:
                f.write('Command-Line Arguments : {} \nMethod Selected: {} \nRunning {} \n'.format(sys.argv, self.algorithm, trace_file))
                f.write('path_to_goal: {} \ncost_of_path: {} \nnodes_expanded: {} \nsearch_depth: {} \nmax_search_depth: {} \n'.format(self.path, self.path_cost, self.nodes_expanded, self.path_depth, self.max_frontier_size))
                for state in self.path:
                    f.write('{}\n'.format(state))
                f.write('Goal Reached: True \n')
                
                # close the file
                f.close()
    
    # method to handle 
    def run(self):
        if self.algorithm == 'bfs':
            self.bfs()
        elif self.algorithm == 'dfs':
            self.dfs()
        elif self.algorithm == 'a*':
            self.a_star()
        elif self.algorithm == 'greedy':
            self.greedy_search()
        elif self.algorithm == 'ucs':
            self.uniform_cost()
        elif self.algorithm == 'ids':
            self.ids()
        elif self.algorithm == 'dls':
            self.dls()
        else:
            self.a_star() #default algorithm
        try :
            self.print_result()
            self.dump_file()
        # except what is the error
        except Exception as e:
            print(e)
            print('Error in print_result or dump_file')
            print('Exiting...')
            sys.exit(1)

# main function
def main():
    # parse command line arguments
    parser = argparse.ArgumentParser() 
    parser.add_argument('start_state', help='start state') 
    parser.add_argument('goal_state', help='goal state') 
    parser.add_argument('algorithm', help='algorithm') 
    parser.add_argument('dump_flag', help='dump flag') 
    args = parser.parse_args()     
    start_state = file_to_matrix(args.start_state) 
    goal_state = file_to_matrix(args.goal_state) 
    algorithm = args.algorithm 
    if args.dump_flag == 'true': 
        dump_flag = True 
    else: 
        dump_flag = False 
    # create a search object
    search = Algorithms(start_state, goal_state, algorithm, dump_flag)
    # run the search
    search.run()
     
if __name__ == '__main__':
    main()
    
