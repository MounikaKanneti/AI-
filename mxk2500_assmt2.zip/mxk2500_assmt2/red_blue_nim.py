

import math
import random
import sys


def computer_move(red, blue, depth):
    
        # Compute the best move based on the minimax algorithm
        best_move = max_value(red, blue, depth, -math.inf, math.inf)[1]

        

        return best_move


def max_value(red, blue, depth, alpha, beta):
    if red==0 or blue==0:
     return -1,None
    
    if depth == 0:
        return evaluate(red, blue), None
    
    v = -math.inf
    move = None
    
    for pile in ["red", "blue"]:
        if pile == "red":
            new_red = red - 1
            new_blue = blue
        else:
            new_red = red
            new_blue = blue - 1
        
        value, _ = min_value(new_red, new_blue, depth - 1, alpha, beta)
        if value > v:
            v = value
            move = pile
        if v >= beta:
            return v, move
        alpha = max(alpha, v)
    
    return v, move

def min_value(red, blue, depth, alpha, beta):
    if red==0 or blue==0:
     return +1,None
    
    if depth == 0:
        return evaluate(red, blue), None
    
    v = math.inf
    move = None
    
    for pile in ["red", "blue"]:
        if pile == "red":
            new_red = red - 1
            new_blue = blue
        else:
            new_red = red
            new_blue = blue - 1
        
        value, _ = max_value(new_red, new_blue, depth - 1, alpha, beta)
        if value < v:
            v = value
            move = pile
        if v <= alpha:
            return v, move
        beta = min(beta, v)
    
    return v, move
def evaluate(red, blue):
    
    return red*2 + blue*3



def play(num_red, num_blue, depth, first_player):
    red = num_red
    blue = num_blue
    print("Starting with", red, "red marbles and", blue, "blue marbles.")
    print("First player is", first_player)

    while True:
        if red==0 or blue==0:
            print(f"{first_player} win with {evaluate(red,blue)} points")
            break

        if first_player == "computer":
            print("Current State:", red, "red marbles and", blue, "blue marbles.")
            pile = computer_move(red, blue, depth)
            print("Computer chooses", pile)
            if pile == "red":
                red -= 1
            else:
                blue -= 1
            first_player = "human"
        else:
            while True:
                print("Current State:", red, "red marbles and", blue, "blue marbles.")
                pile = input("Choose a pile (red or blue): ")
                if pile in ["red", "blue"]:
                    break
                else:
                    print("Invalid input. Please choose red or blue.")

            if pile == "red":
                red -= 1
            else:
                blue -= 1
            first_player = "computer"
if __name__=="__main__":
   red = sys.argv[1]
   blue = sys.argv[2]
   if(len(sys.argv)<5):
    depth = sys.argv[3]
    firstplayer="computer"
   else:
    firstplayer = sys.argv[3]
    depth = sys.argv[4]

   while not (red.isnumeric() and blue.isnumeric()):
         print("Entered invalid pile(s) number\n Please enter inputs again")
         red = input("Enter red pile")
         blue = input("Enter blue pile")
         firstplayer = input("who is playing(computer/human)")
         depth = input("Enter the depth value")
         
         
   play(int(red),int(blue),int(depth),firstplayer)