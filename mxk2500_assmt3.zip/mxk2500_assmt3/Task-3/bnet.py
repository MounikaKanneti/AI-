import sys
import pandas as pd

def return_learned_probs(training_data):
    with open(training_data, 'r') as file:
        lines = file.readlines()
    data = []
    for line in lines:
        values = line.strip().split("     ")
        values = [int(value) for value in values if value]  # Convert to integers
        data.append(values)

    alphabets = ["B", "G", "C", "F"]
    df = pd.DataFrame(data, columns=alphabets)
    length = len(df)
    prob_of_b = df["B"].value_counts() / length
    prob_of_gb = df.groupby(["G", "B"])["B"].count() / df.groupby("B")["B"].count()
    prob_of_fgc = df.groupby(["F", "G", "C"])["F"].count() / df.groupby(["G", "C"])["F"].count()
    prob_of_c = df["C"].value_counts() / length
    return prob_of_b, prob_of_gb, prob_of_fgc, prob_of_c

def print_learned_probs(prob_of_b, prob_of_gb, prob_of_fgc, prob_of_c):
    print("Table of P(B):")
    for b, prob in prob_of_b.items():
        print("P(B={}) = {}".format(b, prob))
    print("\nTable of P(G|B):")
    for (g, b), prob in prob_of_gb.items():
        print("P(G={} | B={}) = {}".format(g, b, prob))
    print("\nTable of P(F|G,C):")
    for (f, g, c), prob in prob_of_fgc.items():
        print("P(F={} | G={}, C={}) = {}".format(f, g, c, prob))
    print("\nTable of P(C):")
    for c, prob in prob_of_c.items():
        print("P(C={}) = {}".format(c, prob))

def return_jpd_value(prob_of_b, prob_of_gb, prob_of_fgc, prob_of_c, **var_arguments):
    jpd_result = 1.0
    if 'B' in var_arguments:
        value_of_b_alpha = int(var_arguments.get('B'))
        jpd_result *= prob_of_b[value_of_b_alpha]
    if 'G' in var_arguments and 'B' in var_arguments:
        value_of_g_alpha = int(var_arguments.get('G'))
        value_of_b_alpha = int(var_arguments.get('B'))
        jpd_result *= prob_of_gb[(value_of_g_alpha, value_of_b_alpha)]
    if 'F' in var_arguments and 'G' in var_arguments and 'C' in var_arguments:
        value_of_f_alpha = int(var_arguments.get('F'))
        value_of_g_alpha = int(var_arguments.get('G'))
        value_of_c_alpha = int(var_arguments.get('C'))
        jpd_result *= prob_of_fgc[(value_of_g_alpha, value_of_c_alpha, value_of_f_alpha)]
    if 'C' in var_arguments:
        value_of_c_alpha = int(var_arguments.get('C'))
        jpd_result *= prob_of_c[value_of_c_alpha]
    return jpd_result

def inference_by_enumeration(prob_of_b, prob_of_gb, prob_of_fgc, prob_of_c, queries, evidences=None):
    abc = 0.0
    efg = 0.0
    alphabets = ['B', 'G', 'C', 'F']
    if evidences is None:
        evidences = {}
    for value_of_b_alpha in [False, True]:
        for value_of_g_alpha in [False, True]:
            for value_of_c_alpha in [False, True]:
                for value_of_f_alpha in [False, True]:
                    event = {'B': value_of_b_alpha, 'G': value_of_g_alpha, 'C': value_of_c_alpha, 'F': value_of_f_alpha}
                    abc_flag= False
                    efg_flag= True
                    for e in evidences:
                        if event[e]!=evidences[e]:
                            efg_flag= False
                            break
                    if efg_flag==True:
                        abc_flag= True
                        for q in queries:
                            if event[q]!=queries[q]:
                                abc_flag= False
                                break
                    prob = return_jpd_value(prob_of_b, prob_of_gb, prob_of_fgc, prob_of_c, **event)
                    if efg_flag==True:
                        efg += prob
                    if abc_flag==True:
                        abc += prob

    final_result = abc / efg
    return final_result


if len(sys.argv) < 4:
    print("Wrong argument values")
else:
    training_data = sys.argv[1]
    prob_of_b, prob_of_gb, prob_of_fgc, prob_of_c = return_learned_probs(training_data)
    print_learned_probs(prob_of_b, prob_of_gb, prob_of_fgc, prob_of_c)
    queries = {}
    evidences = {}
    beg_idx_q = 2
    end_idx_q = len(sys.argv) - 1
    if 'given' in sys.argv:
        end_idx_q = sys.argv.index('given') - 1
        beg_idx_e = end_idx_q + 2
        for i in range(beg_idx_e, len(sys.argv)):
            evidence = sys.argv[i]
            alphabet = evidence[0]
            alpha_value = evidence[1] == 't'
            evidences[alphabet] = alpha_value
    for i in range(beg_idx_q, end_idx_q + 1):
        query = sys.argv[i]
        alphabet = query[0]
        alpha_value = query[1] == 't'
        queries[alphabet] = alpha_value
    d = {}
    if queries and not evidences:
        final_result = return_jpd_value(prob_of_b, prob_of_gb, prob_of_fgc, prob_of_c, **queries)
        print(
            f"\nP({', '.join(f'{alphabet}={alpha_value}' for alphabet, alpha_value in queries.items())}) = {final_result}")
    else:
        final_result = inference_by_enumeration(prob_of_b, prob_of_gb, prob_of_fgc, prob_of_c, queries, evidences)
        print(f"\nP({', '.join(f'{alphabet}={alpha_value}' for alphabet, alpha_value in queries.items())} | "
              f"{', '.join(f'{alphabet}={alpha_value}' for alphabet, alpha_value in evidences.items())}) = {final_result}")