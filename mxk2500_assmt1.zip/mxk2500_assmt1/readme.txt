NAME & UTA ID
NAME:MOUNIKA KANNETI
UTA ID : 1002032500

What programming language is used for this task. (Make sure to also give version and subversion numbers)

Python  3.9.7


How the code is structured.

we have a single file expense_8_puzzle.py where it has following functions.

 file_to_matrix() : This function is used to parse the input file and return the state of the puzzle
 blank_tile():  helper function to get the blank tile
 get_actions(): get actions function is used to get the list of actions that can be taken from the current state of the puzzle. The for loop is used to iterate over each action in the list of actions. The copy.deepcopy() function is used to create a deep copy of the state of the puzzle. The get_successor() function is used to get the successor state of the current state. The Node() function is used to create a new node with the successor state as the state of the puzzle. The new node is then appended to the list of child nodes.
 get_successor():it will perform the operations (up,down,left,right) on the given state depending on the action we provided.
 get_cost(): get cost taken to reach the current state. The function takes the action as input and returns the cost of the action
 get_path(): get path from the start state to the goal state. The function takes the node as input and returns the path from the start state to the goal state.
 The path is stored in a list. The path is traversed from the goal state to the start state. The action taken to reach the current state is appended to the path. The parent node is set as the current node. The path is reversed to get the path from the start state to the goal state. The path is returned.
 get_path_cost(): get cost of the path from the start state to the goal state. The function takes the node as input and returns the cost of the path from the start state to the goal state. The cost of the path is the sum of the costs of the actions taken to reach the goal state from the start state. The cost of the action is the number in the action. The cost of the path is the sum of the costs of the actions taken to reach the goal state from the start state. 
 The parent node is set as the current node. The cost of the path is returned.
 get_path_depth(): get depth of the path from the start state to the goal state. The function takes the node as input and returns the depth of the path from the start state to the goal state. The depth of the path is the number of actions taken to reach the goal state from the start state. The parent node is set as the current node. The depth of the path is returned.
 get_actions(): get actions function is used to get the list of actions that can be taken from the current state of the puzzle. The for loop is used to iterate over each action in the list of actions. The copy.deepcopy() function is used to create a deep copy of the state of the puzzle. The get_successor() function is used to get the successor state of the current state. The Node() function is used to create a new node with the successor state as the state of the puzzle. The new node is then appended to the list of child nodes.
 get_child_nodes(): get child nodes for generating the child nodes of a given node. The function takes the node as input and returns a list of child nodes.
 bfs(): Performs a breadth-first search to find a path from start to goal state.
 dfs(): Performs a depth-first search to find a path from start to goal state.
 ids(): Performs Iterative Deepening Search to find a path from start to goal state.
 dls(): Performs depth-limited search to find a path from start to goal state.
 ucs(): Performs Uniform cost search to find a path from start to goal state.
 heuristic(): Returns the Manhattan distance between a node and the goal node.
 a_star(): Performs A* search to find a path from start to goal state.
 greedy_search(): Performs greedy search to find a path from start to goal state.


How to run the code:
1. To begin, open the Command Prompt.
2. Then, set the path in the command prompt to the location of the files. 
3. place both start.txt and goal.txt in the same folder
4. if you require to trace file:
 Run the command as: expense_8_puzzle.py start.txt goal.txt alg true
	for a* alg=a*
		
	for greedy alg=greedy
		
	for ucs alg=ucs
		
	for ids alg=ids
		
	for dls alg=dls
         
            For dls it will ask the user for a limit for DLS to perform. 
	for dfs alg=dfs
		
	for bfs alg=bfs
 5. If you don't need a trace file, run the same commands without the "true" parameter. 
 6. If no algorithm or value is mentioned, A* will be considered.
 7. Finally, if no true or false value is mentioned in the dumpfile place, it will be considered false.
		







 




