NAME & UTA ID
NAME:MOUNIKA KANNETI
UTA ID : 1002032500

What programming language is used for this task. (Make sure to also give version and subversion numbers)

Python  3.9.7


How the code is structured.
I have created individual tasks in seperate folders namely Task 1 , Task 2, Task 3 where each folder contains source file named bnet.py

How to run the code:
1. To begin, open the Command Prompt.
2. Then, set the path in the command prompt to the location of the files. 
3. For Task 1: Run the command as :python bnet.py training_data.txt 
   For Task 2: Run the command as :python bnet.py training_data.txt Bt Gf Ct Ff
   For Task 3: Run the command as :python bnet.py training_data.txt Bt Gf given Ff

where training_data is the text file which contains training data.
 




