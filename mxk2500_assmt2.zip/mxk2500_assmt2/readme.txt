NAME & UTA ID
NAME:MOUNIKA KANNETI
UTA ID : 1002032500

What programming language is used for this task. (Make sure to also give version and subversion numbers)

Python  3.9.7


How the code is structured.

we have a single file red_blue_nim.py where it has following functions.

computer_move() :Using the depth minmax algorithm with alpha-beta pruning this function is used to calculate the best move for the computer algorith.

max_value(): Using the minimax function with alpha-beta pruning, the max_value function moves the greatest utility value that can be calculated from a given game state along with the related move. The function takes into consideration every possible move changes to the existing move and prune all  parts that are unlikely to generate a better result.

min_value():Using the minimax function with alpha-beta pruning, the min_value function moves the least utility value that can be calculated from a given game state along with the related move. The function takes into consideration every possible move changes to the existing move and prune all  parts that are unlikely to generate a better result.

evaluate():The evaluate function generates a heuristic evaluation value for a particular game state depending on the number of red and blue pieces on the board.


play(): The play function performs a game in which a human player competes against a computer player using the minimax algorithm with alpha-beta pruning. This function alternates between the two players turns until one person runs out of marbles. The maximum depth of the search method, the total number of red and blue marbles, and the player who moves first are all inputs to the function.


How to run the code:
1. To begin, open the Command Prompt.
2. Then, set the path in the command prompt to the location of the files. 
3. Run the command as:python red_blue_nim.py number of red tiles number of blue tiles first player depth
                                                
	               python red_blue_nim.py 5 3 computer 3







 




